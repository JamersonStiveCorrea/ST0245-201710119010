
/**
 * Write a description of class Punto2 here.
 * 
 * @author (Jamerson Stive Correa Correa) 
 * @version (2017/08/14)
 */
import java.util.concurrent.TimeUnit;
public class TablasMultiplicar
{
    public static void tablasDeMultiplicar(int n){
        for (int i = 0; i <= n; i++){
            for (int j = 0; j <= n; j++){
                System.out.println(i+"*"+j+"="+i*j);
            }
        }
    }

    public static long tomarTiempoMult(int n){
        long startTime = System.currentTimeMillis();
        tablasDeMultiplicar(n);
        long estimatedTime = System.currentTimeMillis() - startTime;
        return estimatedTime;
    }

    public static void main(String[] args){
        // for(int i = 1; i <= 10; i = i + 1)
        System.out.println(100+" "+tomarTiempoMult(100));
    }
}
