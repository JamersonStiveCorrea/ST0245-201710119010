
/**
 * Write a description of class Taller4 here.
 * 
 * @author El profesor 
 * @version (2017/08/14)
 */
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class ArraySum
{

    public static void arraySum (int  [] Sum){
        int c = 0;
        for (int i = 0; i<Sum.length; i++) 
        {
            c = c + Sum[i];  
            /*try{
            TimeUnit.SECONDS.sleep(1);
            }
            catch(Exception e)
            {
            }*/

        }
        System.out.println (c);
    }

    public static int[] generarArregloDeTamanoN(int n){
        int max = 5000;
        int[] array = new int[n];
        Random generator = new Random();
        for (int i =0; i<n; i++)
            array[i] = generator.nextInt(max);
        return array;
    }

    public static void main(String[] args){
        for(int i = 1; i <= 10000000; i = i + 1)
            System.out.println(i+" "+tomarTiempoSum(i));
    }

    public static long tomarTiempoSum(int n){
        int[] a = generarArregloDeTamanoN(n);
        long startTime = System.currentTimeMillis();
        arraySum(a);
        long estimatedTime = System.currentTimeMillis() - startTime;
        return estimatedTime;
    }

}
