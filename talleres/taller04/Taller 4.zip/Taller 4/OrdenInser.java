
/**
 * Write a description of class OrdenInser here.
 * 
 * @author (Jamerson Stive Correa) 
 * @version (2017/08/14)
 */
import java.util.Random;
public class OrdenInser
{
    public static int [] ordenar(int [] array){
        int n = array.length;
        int temp = 0;
        for(int i =0;i <= n-1;i++){
            int j = i;
            while(j > 0 && array[j-1] > array[j]){
                temp = array[j];
                array[j] = array[j-1];
                array[j-1] = temp;  
                j = j-1;
            }
        }
        return array;
    }

    public static int[] generarArregloDeTamanoN(int n){
        int max = 5000;
        int[] array = new int[n];
        Random generator = new Random();
        for (int i =0; i<n; i++)
            array[i] = generator.nextInt(max);
        return array;
    }

    public static long tomarTiempoOrdenar(int n){
        int[] a = generarArregloDeTamanoN(n);
        long startTime = System.currentTimeMillis();
        //int[] array = new int[n];
        ordenar(a);
        long estimatedTime = System.currentTimeMillis() - startTime;
        return estimatedTime;
    }

    public static void main(String[] args){
        // for(int i = 1; i <= 10; i = i + 1)
        System.out.println(100000+" "+tomarTiempoOrdenar(100000));
    }

    /** para ( i <- 0 hasta n-1) Hacer //Incluye a n-1 este tipo de “hasta”
    j <- i;
    Mientras j > 0 && A[j-1] > A[j] Hacer
    temp <- A[j];
    A[j] <- A[j-1];
    A[j-1] <- temp;
    j <- j - 1;
    FinMientras
    FinPara
    FinProceso*/

}
